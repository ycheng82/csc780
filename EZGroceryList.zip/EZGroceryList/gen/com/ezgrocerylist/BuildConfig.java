/** Automatically generated file. DO NOT MODIFY */
package com.ezgrocerylist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}